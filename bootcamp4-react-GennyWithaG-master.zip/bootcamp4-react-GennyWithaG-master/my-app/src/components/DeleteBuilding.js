import React, {useState} from 'react';

const DeleteBuilding = (props) => {
  const handleClick = (value) => {
    if(document.getElementsByTagName('input')[6].value && document.getElementsByTagName('input')[7].value)
    {
      const deleteBuild = props.data.filter((building) => building.name === document.getElementsByTagName('input')[6].value);

    document.getElementsByTagName('input')[6].value = "";
    document.getElementsByTagName('input')[7].value = "";
     let deleteID = deleteBuild[0].id;
     props.data.splice((deleteID -1), 1);
     props.data.forEach((item) => {
       if(item.id> deleteID)
       {
          item.id--;
       }

     });

    props.updateData(props.data.splice(0,0));
  }

}


  return (
      <div>
      <form action="/action_page.php" method="get">
            <h1> Delete a Building </h1>
            <h2> Must enter both name and code </h2>
            <label for="Name">Name:</label>
            <input type="text" id="Name" name="newName" placeholder="Type Name"/>

            <label for="Code">Code:</label>
            <input type="text" id="Code" name="newCode" placeholder="Type Code" />

            <p></p>
            <button type="button" value="Delete" onClick = {handleClick}>Delete</button>

            <p></p>
            </form>
      </div>
  );




};
export default DeleteBuilding;
