import React, {useState} from 'react';

const NewBuilding = (props) => {

  const handleClick = (value) => {
    if(document.getElementsByTagName('input')[1].value && document.getElementsByTagName('input')[2].value)
    {
        props.updateData(
          props.data.push(
            {
                id: props.data.length+1,
                name: document.getElementsByTagName('input')[1].value,
                code: document.getElementsByTagName('input')[2].value,
                address: document.getElementsByTagName('input')[3].value,
                coordinates:
                {
                  latitude: document.getElementsByTagName('input')[4].value,
                  longitude: document.getElementsByTagName('input')[5].value
                }
            }
          )
        );
    }
    document.getElementsByTagName('input')[1].value = "";
    document.getElementsByTagName('input')[2].value = "";
    document.getElementsByTagName('input')[3].value = "";
    document.getElementsByTagName('input')[4].value = "";
    document.getElementsByTagName('input')[5].value = "";
  }
  return (
      <div>
      <form action="/action_page.php" method="get">
            <h1> Add a Building </h1>
            <h2> Must enter at least name and code </h2>
            <label for="Name">Name:</label>
            <input type="text" id="Name" name="newName" placeholder="Type Name"/>

            <label for="Code">Code:</label>
            <input type="text" id="Code" name="newCode" placeholder="Type Code" />

            <label for="Add">Address:</label>
            <input type="text" id="Add" name="newAddress" placeholder="Type Address"/>

            <label for="Lat">Latitude:</label>
            <input type="float" id="Lat" name="newLat" placeholder="Type Latitude"/>

            <label for="Long">Longitude:</label>
            <input type="float" id="Long" name="newLong" placeholder="Type Longitude"/>

            <p></p>
            <button type="button" value="Add" onClick = {handleClick}>Add</button>
            <p></p>
            </form>
      </div>
  );




};
export default NewBuilding;
