import React from 'react';

const ViewBuilding = (props) => {
    return (
        <div>
            <p>
                {' '}
                <i>Click on a name to view more information</i>
            </p>
        </div>
    );
};
export default ViewBuilding;
